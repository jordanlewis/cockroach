create view vb as
SELECT va."?column?"
FROM va;

alter table vb
  owner to jordan;

