create view va as
SELECT 1;

alter table va
  owner to jordan;

